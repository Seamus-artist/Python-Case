
import os
import urllib
import functools

import numpy as np
import pandas as pd

# if we don't have the stations file locally, download it
if not os.path.isfile('stations.txt'):
    urllib.request.urlretrieve('https://www1.ncdc.noaa.gov/pub/data/ghcn/daily/ghcnd-stations.txt',
                               'stations.txt')
    
  
# FORMAT OF "ghcnd-stations.txt"
# ------------------------------
# Variable   Columns   Type
# ------------------------------
# ID            1-11   Character
# LATITUDE     13-20   Real
# LONGITUDE    22-30   Real
# ELEVATION    32-37   Real
# STATE        39-40   Character
# NAME         42-71   Character
# GSN FLAG     73-75   Character
# HCN/CRN FLAG 77-79   Character
# WMO ID       81-85   Character
# ------------------------------


# parse the stations.txt file as described in video 05_02
allstations = np.genfromtxt('stations.txt', delimiter=[11,9,10,7,3,31,4,4,6],
                                            usecols=[0,1,2,3,4,5,6,7,8],
                                            names=['id','latitude','longitude','elevation','state','name','gsn','hcn','wmo'],
                                            dtype=['U11','d','d','d','U3','U31','U4','U4','U6'],
                                            autostrip=True)

def getfile(station_name):  
    """下载指定气象站（station_name）的dly文件，并返回本地文件名。
    
    如果station_name不在列表中，则查找以station_name开头的站点，
    但优先考虑HCN和GSN站点。"""
    
    # 本地文件的名称
    station_file = f'{station_name}.dly'
    
    # 如果我们本地没有这个文件...
    if not os.path.isfile(station_file):
        # 从stations.txt文件中找出气象站的ID
        
        # 首先查找所有以请求名称开头的站点
        stations = allstations[np.char.find(allstations['name'], station_name) == 0]

        if len(stations) == 0:
            raise IOError("气象站不可用。")  # 如果没有找到任何站点，则抛出错误
        
        # 如果有GSN站点可用，则优先选择GSN站点，其次选择HCN站点，否则默认选择第一个匹配的站点
        if np.any(stations['gsn'] != ''):
            station = stations[stations['gsn'] != ''][0]
        elif np.any(stations['hcn'] != ''):
            station = stations[stations['hcn'] != ''][0]
        else:
            station = stations[0]
        
        print(f"使用 {station['name']} 站点的数据。")  # 打印正在使用哪个站点的数据
        
        # 构造我们期望找到数据的URL
        url = f'https://www1.ncdc.noaa.gov/pub/data/ghcn/daily/all/{station["id"]}.dly'
        
        print(f'正在下载 {url}...')  # 打印正在下载的URL
        
        # 将文件下载到本地
        urllib.request.urlretrieve(url, station_file)
        
    return station_file  # 返回本地文件名

    

# FORMAT OF "*.dly" files
# ------------------------------
# Variable   Columns   Type
# ------------------------------
# ID            1-11   Character
# YEAR         12-15   Integer
# MONTH        16-17   Integer
# ELEMENT      18-21   Character
# VALUE1       22-26   Integer
# MFLAG1       27-27   Character
# QFLAG1       28-28   Character
# SFLAG1       29-29   Character
# VALUE2       30-34   Integer
# MFLAG2       35-35   Character
# QFLAG2       36-36   Character
# SFLAG2       37-37   Character
#   .           .          .
#   .           .          .
#   .           .          .
# VALUE31    262-266   Integer
# MFLAG31    267-267   Character
# QFLAG31    268-268   Character
# SFLAG31    269-269   Character
# ------------------------------
    

# cache the results of this call so we do the work only once
@functools.lru_cache()
def getdata(station_name):
    """为给定的气象站名称创建一个包含清洁天气数据的pandas DataFrame。
    
    如果找不到该气象站名称，则查找以该气象站名称开头的站点，
    但优先考虑HCN和GSN站点。"""
    
    station_file = getfile(station_name)  # 获取对应气象站的本地数据文件路径
    
    # 根据readme.txt中的定义加载固定宽度文件
    # 注意：每个月有31个值+标志序列（有些月份会未定义）
    w = np.genfromtxt(station_file,
                      delimiter=[11,4,2,4] + [5,1,1,1]*31,
                      # 我们不使用每日标志，所以这个列表变成了
                      # 0, 1, 2, 3, 4, 8, 12, 16, 20, 24...
                      usecols=[0,1,2,3] + list(range(4,4*32,4)),
                      # 每日观测值的名称将是day1, day2, day3,...
                      names=['id','year','month','element'] + [f'day{i}' for i in range(1,32)],
                      dtype=['U11','i','i','U4'] + ['d']*31,
                      autostrip=True)

    # 将numpy记录数组转换为pandas DataFrame，这是一个更强大的对象
    # 用于清洗和重构数据
    pw = pd.DataFrame(w)

    # 添加调试信息
    print(pw.columns)  # 打印列名
    print(pw.head())   # 打印前几行数据

    # 将每日观测值"融化"成每条记录一个每日观测值，
    # 并将列名存储在'day'中
    pw = pd.melt(pw, id_vars=['id','year','month','element'], var_name='day', value_name='value')
    
    # 丢弃空观测值（-9999表示缺失数据）
    pw = pw[pw.value != -9999]

    # 只保留最低/最高温度、降水量和降雪量数据
    pw = pw[pw.element.isin(['TMAX','TMIN','PRCP','SNOW'])]

    # 将'day1', 'day2'等转换为一年中的第几天
    pw['day'] = pw.day.apply(lambda x: int(x[3:]))

    # 根据年、月、日创建日期
    pw['date'] = pd.to_datetime(pw[['year','month','day']])

    # 只保留数据、元素和值列
    pw = pw[['date','element','value']]

    # 重构DataFrame，使同一天的不同元素出现在同一行
    # （基本上是"融化"操作的相反操作）
    pw = pw.pivot(index='date', columns='element')['value']
    pw.columns.name = None  # 移除列名的名称
    
    # 只选择我们关心的列：最低温度、最高温度、降水量和降雪量
    pw = pw[['TMIN','TMAX','PRCP','SNOW']]
    
    # 最后，将温度转换为摄氏度（如果原始数据是以十分之一摄氏度为单位的话）
    pw['TMIN'] /= 10.0
    pw['TMAX'] /= 10.0
    
    # 完成所有操作，返回处理后的DataFrame
    return pw



def getyear(station_name, elements, year):
    """创建一个长度为365的NumPy记录数组，包含指定气象站（station_name）在指定年份（year）的请求元素（TMIN/TMAX/PRCP/SNOW）的天气数据。
    
    如果station_name不在列表中，则查找以station_name开头的站点，
    但优先考虑HCN和GSN站点。"""
        
    alldata = getdata(station_name)  # 获取指定气象站的所有清洁天气数据
    
    # 根据年份选择数据，并去除闰年多出的一天
    # 然后提取"element"列的数据
    yeardata = alldata[(alldata.index.year == year) & (alldata.index.dayofyear < 366)]
    
    # 创建一个充满nan的空记录数组
    empty = np.full(365, np.nan, dtype=[(element, np.float64) for element in elements])
    
    for element in elements:  # 遍历请求的每个元素
        # 使用一年中的第几天（1到365）作为索引填充数据
        empty[element][yeardata.index.dayofyear - 1] = yeardata[element].values
    
    return empty  # 返回填充好的记录数组

